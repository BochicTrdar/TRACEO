==============================================================================
Faro, Seg 11 Abr 2022 16:01:01 WEST 

Gaussian Beam Ray Tracing model
by Orlando Camargo Rodríguez

To compile just type "make" in your commandline 
==============================================================================

